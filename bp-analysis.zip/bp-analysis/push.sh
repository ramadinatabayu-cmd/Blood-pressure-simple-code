#!/usr/bin/env bash
# Pemakaian: ./push.sh https://github.com/USERNAME/bp-analysis.git
set -e
git init -b main
git add .
git commit -m "Initial commit: Blood Pressure Analysis"
git remote add origin "$1"
git push -u origin main
