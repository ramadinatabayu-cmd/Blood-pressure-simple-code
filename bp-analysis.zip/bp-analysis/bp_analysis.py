def kategori(s, d):
    if s < 90 or d < 60:
        return "Tekanan Darah Rendah"
    if s >= 140 or d >= 90:
        return "Tekanan Darah Tinggi"
    if s >= 120 or d >= 80:
        return "Tekanan Darah Meningkat"
    return "Tekanan Darah Normal"

SARAN = {
    "Tekanan Darah Rendah": "Makan bergizi, minum cukup, istirahat. Jika pusing, duduk/berbaring. Periksa ke tenaga kesehatan bila berlanjut.",
    "Tekanan Darah Normal": "Pertahankan pola hidup sehat dan periksa tekanan darah berkala.",
    "Tekanan Darah Meningkat": "Kurangi garam, olahraga teratur, ukur ulang dan konsultasikan ke tenaga kesehatan.",
    "Tekanan Darah Tinggi": "Batasi garam, kelola stres, dan segera konsultasi ke dokter.",
}

HEART = r"""
   ***   ***
 ***** *****
 ***********
  *********
   *******
    *****
     ***
      *
"""

def main():
    print("=" * 36)
    print("      BLOOD PRESSURE ANALYSIS")
    print("=" * 36)
    s = float(input("Masukkan sistolik  : "))
    d = float(input("Masukkan diastolik : "))
    k = kategori(s, d)
    print(f"\nTekanan darah: {s:.0f}/{d:.0f} mmHg")
    print("Kategori:", k)
    print(HEART)
    print(SARAN[k])


if __name__ == "__main__":
    main()
