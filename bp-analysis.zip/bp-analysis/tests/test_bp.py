import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent))
from bp_analysis import kategori

def test_normal():   assert kategori(115, 75) == "Tekanan Darah Normal"
def test_rendah():   assert kategori(85, 55) == "Tekanan Darah Rendah"
def test_meningkat():assert kategori(125, 78) == "Tekanan Darah Meningkat"
def test_tinggi():   assert kategori(150, 95) == "Tekanan Darah Tinggi"
def test_batas_120_80(): assert kategori(120, 80) == "Tekanan Darah Meningkat"
