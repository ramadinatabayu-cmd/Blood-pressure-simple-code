# ❤ Blood Pressure Analysis

![CI](../../actions/workflows/ci.yml/badge.svg)

Analisis kategori tekanan darah dengan **versi web** (animasi jantung + suara klik) dan **versi terminal (Python)**.

> ⚠️ Hanya untuk edukasi, bukan pengganti diagnosis dokter.

## Fitur
- Kategori: Rendah, Normal, Meningkat, Tinggi (berdasarkan ambang sistolik/diastolik)
- Jantung berdenyut dengan warna dan kecepatan sesuai kategori
- Efek suara klik (Web Audio, tanpa file audio)
- Unit test + GitHub Actions CI, deploy otomatis ke GitHub Pages

## Cara pakai
**Web:** buka `index.html` di browser, atau lewat GitHub Pages.

**Terminal:**
```bash
python bp_analysis.py
```

**Test:**
```bash
pip install pytest && pytest
```

## Kategori
| Kategori | Kriteria (mmHg) |
|---|---|
| Rendah | sistolik < 90 atau diastolik < 60 |
| Normal | < 120 dan < 80 |
| Meningkat | sistolik ≥ 120 atau diastolik ≥ 80 |
| Tinggi | sistolik ≥ 140 atau diastolik ≥ 90 |

## Deploy ke GitHub Pages
Settings → Pages → Source: **GitHub Actions**. Setiap push ke `main` otomatis terbit.

## Lisensi
MIT
